
#include "AD5940.h"
#include <stdio.h>
#include "string.h"
#include "math.h"
#include "BodyImpedance.h"
#include "adi_i2c.h"                    // AnalogDevices::Device:Drivers:I2C
#include "adi_pwr.h"                    // AnalogDevices::Device:Drivers:Power
#include "adi_gpio.h"                   // AnalogDevices::Device:Drivers:GPIO
#include <stdint.h>
#include <math.h>
#include <stdlib.h>
/***********************************************************************************************/
#include <sys/platform.h>
#include "adi_initialize.h"
#include <stdio.h>
#include <system_ADuCM3029.h>
#include <board.h>                  
#include <sys/platform.h>
#include <stdio.h>
#include <system_ADuCM3029.h>
#include <stdint.h>
#include <common.h>
#include "ADUCM3029.h"
#include <adi_processor.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/gpio/adi_gpio.h>
#include <drivers/i2c/adi_i2c.h>
#include "drivers/pwr/adi_pwr.h"
#include "adi_i2c.h"                    // AnalogDevices::Device:Drivers:I2C
#include <math.h>


unsigned char reg_val;
uint8_t txData[1];							/* Data write to MMA8451 */
uint8_t Chip_Data[1];						/* Device ID = 0x1A */ 
uint8_t Data[2] = {0};								/* Control Reg 2 Data --> Wait till SET */
uint8_t X_Data[2]; 							/* MSB DATA */
uint8_t Y_Data[2];							/* MSB DATA */	
uint8_t Z_Data[2];							/* MSB DATA */
uint8_t x_Data[2];							/* LSB DATA */
uint8_t y_Data[2];							/* LSB DATA */
uint8_t z_Data[2];							/* LSB DATA */
uint8_t SR_Data[1];							/* Status Register --> Wait till SET */
#define SENSITIVITY_2G 4096

uint8_t Z_Data1[2];

int32_t adi_initi2cmux(void);
void Chip_Id(void);
void wCTRL_2(void);
void set_up(void);
void SR_Transaction(void);
void set_calibration(float X_set,float Y_set,float Z_set);


// *** FOR ADXL 345 *** //

uint8_t X_Lis(uint8_t register_name);
uint8_t Y_Lis(uint8_t register_name);
uint8_t Z_Lis(uint8_t register_name);
void setup_Lis(void);
void standby_Lis(void);
float xAccl;
float yAccl;
float zAccl;

// *** *** **** *** *** //

uint8_t X_MSB(void);
uint8_t Y_MSB(void);
uint8_t Z_MSB(void);
uint8_t X_LSB(void);
uint8_t Y_LSB(void);
uint8_t Z_LSB(void);
float X_out[5]={0};
float Y_out[5]={0};
float Z_out[5]={0};
float X_out1[5]={0};
float Y_out1[5]={0};
float Z_out1[5]={0};
float X_out3[5]={0};
float Y_out3[5]={0};
float Z_out3[5]={0};
int Time1[5]={0};
int Time2[5]={0};
int Time3[5]={0};
//float X_set;
//float Y_set;
//float Z_set;
//float X_g;
//float Y_g;
//float Z_g;

ADI_I2C_RESULT result = ADI_I2C_SUCCESS;
uint32_t hwErrors;

#define I2C0_SCL0_PORTP0_MUX ((uint16_t) ((uint16_t) 1<<8))
#define I2C0_SDA0_PORTP0_MUX ((uint16_t) ((uint16_t) 1<<10))

extern uint32_t SystemCoreClock;
uint8_t devMem[ADI_I2C_MEMORY_SIZE]; /* assign memory */
ADI_I2C_HANDLE hDevice;
ADI_I2C_HANDLE adxl;

int count1=0U;
int count2=0U;
int count3=0U;
int count4=0U;
int Time_1=0U;
int Time_2=0U;
int Time_3=0U;
int A_count=0U;


volatile int signal1=0;
volatile int signal2=0;
volatile int signal3=0;

volatile uint32_t myState	 =	 0UL;	

void conf_CLK    ( void );
void conf_Timer0 ( void );
void conf_Timer1 ( void );
void conf_WDT  	 ( void );

extern int32_t adi_initpinmux(void);
int32_t adi_initComponents(void);
ADI_PWR_RESULT  ePwrResult;

/***********************************************************************************************/

#define APPBUFF_SIZE 512
uint32_t AppBuff[APPBUFF_SIZE];

/* Print Data to Terminal */
int32_t BIAShowResult(uint32_t *pData, uint32_t DataCount)  /*** ADD A COUNTER FOR VERIFICATION ***/
{	
	
  float freq;
	//float *val= MMA();
	//printf("a = %f, b = %f, c = %f", val[0],val[1], val[2]);
  fImpPol_Type *pImp = (fImpPol_Type*)pData;
  AppBIACtrl(BIACTRL_GETFREQ, &freq);
	//printf("Freq:%.2f ", freq);
  /*Process data here*/
	
  for(int i=0;i<DataCount;i++)
  {	
		count3++;
    printf("R,%f,P%f,C%d\r\n",pImp[i].Magnitude,pImp[i].Phase*180/MATH_PI,count3);
		//printf("%f,%f\r\n",pImp[i].Magnitude,pImp[i].Phase*180/MATH_PI);
  }
  return 0;
}

/* Initialize AD5940 basic blocks like clock */
static int32_t AD5940PlatformCfg(void)
{
  CLKCfg_Type clk_cfg;
  FIFOCfg_Type fifo_cfg;
  AGPIOCfg_Type gpio_cfg;

  /* Use hardware reset */
  AD5940_HWReset();
  /* Platform configuration */
  AD5940_Initialize();
  /* Step1. Configure clock */
  clk_cfg.ADCClkDiv = ADCCLKDIV_1;
  clk_cfg.ADCCLkSrc = ADCCLKSRC_HFOSC;
  clk_cfg.SysClkDiv = SYSCLKDIV_1;
  clk_cfg.SysClkSrc = SYSCLKSRC_HFOSC;
  clk_cfg.HfOSC32MHzMode = bFALSE;
  clk_cfg.HFOSCEn = bTRUE;
  clk_cfg.HFXTALEn = bFALSE;
  clk_cfg.LFOSCEn = bTRUE;
  AD5940_CLKCfg(&clk_cfg);
  /* Step2. Configure FIFO and Sequencer*/
  fifo_cfg.FIFOEn = bFALSE;
  fifo_cfg.FIFOMode = FIFOMODE_FIFO;
  fifo_cfg.FIFOSize = FIFOSIZE_4KB;                       /* 4kB for FIFO, The reset 2kB for sequencer */
  fifo_cfg.FIFOSrc = FIFOSRC_DFT;
  fifo_cfg.FIFOThresh = 4;//AppBIACfg.FifoThresh;        /* DFT result. One pair for RCAL, another for Rz. One DFT result have real part and imaginary part */
  AD5940_FIFOCfg(&fifo_cfg);                             /* Disable to reset FIFO. */
  fifo_cfg.FIFOEn = bTRUE;  
  AD5940_FIFOCfg(&fifo_cfg);                             /* Enable FIFO here */
  
  /* Step3. Interrupt controller */
  
  AD5940_INTCCfg(AFEINTC_1, AFEINTSRC_ALLINT, bTRUE);           /* Enable all interrupt in Interrupt Controller 1, so we can check INTC flags */
  AD5940_INTCCfg(AFEINTC_0, AFEINTSRC_DATAFIFOTHRESH, bTRUE);   /* Interrupt Controller 0 will control GP0 to generate interrupt to MCU */
  AD5940_INTCClrFlag(AFEINTSRC_ALLINT);
  /* Step4: Reconfigure GPIO */
  gpio_cfg.FuncSet = GP6_SYNC|GP5_SYNC|GP4_SYNC|GP2_TRIG|GP1_SYNC|GP0_INT;
  gpio_cfg.InputEnSet = AGPIO_Pin2;
  gpio_cfg.OutputEnSet = AGPIO_Pin0|AGPIO_Pin1|AGPIO_Pin4|AGPIO_Pin5|AGPIO_Pin6;
  gpio_cfg.OutVal = 0;
  gpio_cfg.PullEnSet = 0;

  AD5940_AGPIOCfg(&gpio_cfg);
  AD5940_SleepKeyCtrlS(SLPKEY_UNLOCK);  /* Allow AFE to enter sleep mode. */
  return 0;
}

/* !!Change the application parameters here if you want to change it to none-default value */
void AD5940BIAStructInit(void)
{
  AppBIACfg_Type *pBIACfg;
  
  AppBIAGetCfg(&pBIACfg);
  
  pBIACfg->SeqStartAddr = 0;
  pBIACfg->MaxSeqLen = 512; /** @todo add checker in function */
  
  pBIACfg->RcalVal = 10000.0;
  pBIACfg->DftNum = DFTNUM_8192;
  pBIACfg->NumOfData = -1;      /* Never stop until you stop it mannually by AppBIACtrl() function */
  pBIACfg->BiaODR = 20;         /* ODR(Sample Rate) 20Hz */
  pBIACfg->FifoThresh = 4;      /* 4 */
  pBIACfg->ADCSinc3Osr = ADCSINC3OSR_2;
}

void AD5940_Main(void)
{
  static uint32_t IntCount;
  static uint32_t count;

	uint32_t temp;
	
	/**********************************************************************************************/
	adi_initComponents();
	SystemInit();
	conf_CLK ();
	//adi_pwr_Init();
	conf_Timer0();
	conf_Timer1();
	conf_WDT  ();
	ePwrResult = adi_pwr_SetClockDivider(ADI_CLOCK_HCLK, 1u);
	ePwrResult = adi_pwr_SetClockDivider(ADI_CLOCK_PCLK, 1u);
	 
	AD5940PlatformCfg();

	(adi_i2c_Open(0, devMem, ADI_I2C_MEMORY_SIZE, &hDevice));
	(adi_i2c_Reset(hDevice));
	(adi_i2c_SetBitRate(hDevice, 400000)); 
	
	(adi_i2c_Open(0, devMem, ADI_I2C_MEMORY_SIZE, &adxl));
	(adi_i2c_Reset(adxl));
	(adi_i2c_SetBitRate(adxl, 400000));
	
	
	//ENBLE ADXL345
	(adi_i2c_SetSlaveAddress(adxl,0x53)); // bottom-end
	setup_Lis();
	
	//ENABLE 2 MMA
	
	printf("ADXL-Done , Begin MMA");
	adi_i2c_SetSlaveAddress(hDevice,0x1C); // bottom-end	
			wCTRL_2();
			ADI_I2C_TRANSACTION read;		
			uint8_t readData[1];
			readData[0]     = 0x2B;  /* address of Read Register */
      read.bReadNotWrite   = true;
      read.bRepeatStart    = false;
			read.nDataSize       = 1;
			read.nPrologueSize = 1;
			read.pData           = Data;
			read.pPrologue = &readData[0];
			do{
			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
			reg_val = Data[0]&0x40;
			} 
			while(reg_val);
			set_up();
			
	printf("ADXL-Done , Begin MMA");

			wCTRL_2();
			readData[0]     = 0x2B;  /* address of Read Register */
      read.bReadNotWrite   = true;
      read.bRepeatStart    = false;
			read.nDataSize       = 1;
			read.nPrologueSize = 1;
			read.pData           = Data;
			read.pPrologue = &readData[0];
			
			do{
			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
			reg_val = Data[0]&0x40;
			} 
			while(reg_val);
			set_up();


printf("MMA1-Done , Begin MMA2");			
	
	
	
	
	
	
	
	//
	__enable_irq ();
	/********************************************************************************************************************/  
 
 
	/********************************************************************************************************************/
	AD5940BIAStructInit(); /* Configure your parameters in this function */
  
  AppBIAInit(AppBuff, APPBUFF_SIZE);    /* Initialize BIA application. Provide a buffer, which is used to store sequencer commands */
  AppBIACtrl(BIACTRL_START, 0);         /* Control BIA measurment to start. Second parameter has no meaning with this command. */
 
  while(1)
  {
		
    /* Check if interrupt flag which will be set when interrupt occured. */
    if(AD5940_GetMCUIntFlag())
    {
      IntCount++;A_count++;
      AD5940_ClrMCUIntFlag(); /* Clear this flag */
      temp = APPBUFF_SIZE;
      AppBIAISR(AppBuff, &temp); /* Deal with it and provide a buffer to store data we got */
      BIAShowResult(AppBuff, temp); /* Show the results to UART */

      if(IntCount == 240)
      {
        IntCount = 0;
        //AppBIACtrl(BIACTRL_SHUTDOWN, 0);
      }
    }
			
		else if(signal1 == 1)
	{	
			adi_i2c_Open (0, devMem, ADI_I2C_MEMORY_SIZE, &hDevice);
	(adi_i2c_Reset(hDevice));
	(adi_i2c_SetBitRate(hDevice, 400000));
			signal1 = 0;
			adi_i2c_SetSlaveAddress(hDevice,0x1C); // bottom-end	
			wCTRL_2();
			ADI_I2C_TRANSACTION read;		
			uint8_t readData[1];
			readData[0]     = 0x2B;  /* address of Read Register */
      read.bReadNotWrite   = true;
      read.bRepeatStart    = false;
			read.nDataSize       = 1;
			read.nPrologueSize = 1;
			read.pData           = Data;
			read.pPrologue = &readData[0];
			do{
			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
			reg_val = Data[0]&0x40;
			} 
			while(reg_val);
			set_up();
			SR_Transaction();

			count1++;Time_1++;
			if(count1==4U){count1=0;for(int i=0;i<4U;i++){printf("Z1,%f,Y1%f,X1%f,T1%d\r\n",Z_out[i],Y_out[i],X_out[i],Time1[i]);}}
			
			
			Z_Data[0] = Z_MSB();Y_Data[0] = Y_MSB();X_Data[0] = X_MSB();
			x_Data[0] = X_LSB();y_Data[0] = Y_LSB();z_Data[0] = Z_LSB();

			X_out[count1] = ((short) (X_Data[0]<<8 | x_Data[0])) >> 2;           // Compute  X-axis output value
			Y_out[count1] = ((short) (Y_Data[0]<<8 | y_Data[0])) >> 2;           // Compute  Y-axis output value
			Z_out[count1] = ((short) (Z_Data[0]<<8 | z_Data[0])) >> 2;           // Compute  Z-axis output value	
			Time1[count1] = Time_1;	
			
				adi_i2c_Close(hDevice);
			
			}
	
	 if(signal2	== 1)
	{	
			signal2 = 0;
					adi_i2c_Open (0, devMem, ADI_I2C_MEMORY_SIZE, &hDevice);
	(adi_i2c_Reset(hDevice));
	(adi_i2c_SetBitRate(hDevice, 400000));
			(adi_i2c_SetSlaveAddress(hDevice,0x1D)); // bottom-end
			wCTRL_2();
			ADI_I2C_TRANSACTION read;		
			uint8_t readData[1];
			readData[0]     = 0x2B;  /* address of Read Register */
      read.bReadNotWrite   = true;
      read.bRepeatStart    = false;
			read.nDataSize       = 1;
			read.nPrologueSize = 1;
			read.pData           = Data;
			read.pPrologue = &readData[0];
			
			do{
			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
			reg_val = Data[0]&0x40;
			} 
			while(reg_val);
			set_up();
			
			SR_Transaction();

		count2++;Time_2++;
		if(count2==4U){count2=0;for(int i=0;i<4U;i++){printf("Z2,%f,Y2%f,X2%f,T2%d\r\n",Z_out1[i],Y_out1[i],X_out1[i],Time2[i]);}}
		
		Z_Data1[0] = Z_MSB();Y_Data[0] = Y_MSB();X_Data[0] = X_MSB();
		x_Data[0] = X_LSB();y_Data[0] = Y_LSB();z_Data[0] = Z_LSB();

		
		X_out1[count2] = ((short) (X_Data[0]<<8 | x_Data[0])) >> 2;           // Compute  X-axis output value
		Y_out1[count2] = ((short) (Y_Data[0]<<8 | y_Data[0])) >> 2;           // Compute  Y-axis output value
		Z_out1[count2] = ((short) (Z_Data[0]<<8 | z_Data[0])) >> 2;           // Compute  Z-axis output value	
		Time2[count2]  =	Time_2;	
			
			adi_i2c_Close(hDevice);
		}
	
	if(signal3 ==1)
	{
		signal3 = 0;
	adi_i2c_Open (0, devMem, ADI_I2C_MEMORY_SIZE, &adxl);
	(adi_i2c_Reset(adxl));
	(adi_i2c_SetBitRate(adxl, 400000));
		
		(adi_i2c_SetSlaveAddress(adxl,0x53)); // bottom-end
		
	//	setup_Lis();
		
			x_Data[0] = X_Lis(0x32);X_Data[0] = X_Lis(0x33);
			y_Data[0] = X_Lis(0x34);Y_Data[0] = X_Lis(0x35);
			z_Data[0] = Z_Lis(0x36);Z_Data[0] = Z_Lis(0x37);
		
		adi_i2c_Close (adxl);
		
		count4++;Time_3++;
		if(count4==4U){count4=0;for(int i=0;i<4U;i++){printf("Z3,%f,Y3%f,X3%f,T3%d\r\n",Z_out3[i],Y_out3[i],X_out3[i],Time3[i]);}}
		
		xAccl = ((X_Data[0] & 0x03) * 256 + (x_Data[0] & 0xFF));
			if(xAccl > 511)
		{
			xAccl -= 1024;
		}

		 yAccl = ((Y_Data[0] & 0x03) * 256 + (y_Data[0] & 0xFF));
		//if(yAccl > 511)
		//{
		//	yAccl -= 1024;
		//}

	 zAccl = ((Z_Data[0] & 0x03) * 256 + (z_Data[0] & 0xFF));
		if(zAccl > 511)
		{
			zAccl -= 1024;
		}	
		

		
		
		X_out3[count4] =  (xAccl/255)*9.89 ;          // Compute  X-axis output value
		Y_out3[count4] =   yAccl;        // Compute  Y-axis output value
		Z_out3[count4] =  (zAccl/255)*9.89 ;        // Compute  Z-axis output value	
		Time3[count4]  =	Time_3;
			
			
			
	}
	
    count++;
    
		//if(count > 1000000)
    //{
    //  count = 0;
      //AppBIAInit(0, 0);    /* Re-initialize BIA application. Because sequences are ready, no need to provide a buffer, which is used to store sequencer commands */
      //AppBIACtrl(BIACTRL_START, 0);          /* Control BIA measurment to start. Second parameter has no meaning with this command. */
   // }
		
		//__WFI();
  }
}


/*******************************MMA8451 I2C SETUP FUNCTIONS************************************************/
/**********************************************************************************************************/
/**********************************************************************************************************/
/**********************************************************************************************************/
/**********************************************************************************************************/
void Chip_Id()
{
				ADI_I2C_TRANSACTION xfr;
		
			uint8_t prologueData[5];
			prologueData[0]     = 0x0D;  /* address of 1st Chip Id Register */
      xfr.bReadNotWrite   = true;
      xfr.bRepeatStart    = true;
			xfr.nDataSize       = 1;
			xfr.nPrologueSize = 1;
			xfr.pData           = Chip_Data;
			xfr.pPrologue = &prologueData[0];;
      
      result = adi_i2c_ReadWrite(hDevice, &xfr, &hwErrors);
			
}
void wCTRL_2()
{
//WRITE 0x40
	
	ADI_I2C_TRANSACTION write;
			txData[0] = 0x40;
			uint8_t writeData[5];
			writeData[0]     = 0x2B;  
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
}



void set_up()
{
//						//RANGE
				ADI_I2C_TRANSACTION write;
				uint8_t writeData[5];
				txData[0] = 0x00 ;
				writeData[0]     = 0x0E;  /* address of XYZ DATA CONFIG */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
				
					
					// HIGH RESOLUTION 
					
				txData[0] = 0x02;
				writeData[0]     = 0x2B;  /* address of 1st Control Reg 2 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
			//DRY INT CTRL REG 4
			
				txData[0] = 0x01;
				writeData[0]     = 0x2D;  
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
			//DRY INT CTRL REG 5
			
				txData[0] = 0x01;
				writeData[0]     = 0x2E;  /* address of 1st Control Reg 5 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
				
				//LOW NOISE
			
				txData[0] =  0x01 | 0x04;        
				writeData[0]     = 0x2A;  /* address of 1st Control Reg 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);	
				
}

void set_calibration(float X_set,float Y_set,float Z_set)
{
					/* Put MMA into Standby Mode */
				ADI_I2C_TRANSACTION write;
				uint8_t writeData[5];
				txData[0] = 0x00 ;
				
				writeData[0]     = 0x2A;  /* address of Control Register 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
				/* Offset control X Register */
				
				txData[0] = X_set ;
				
				writeData[0]     = 0x2F;  /* address of Register */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
				
				/* Offset control Y Register */
					
					
				txData[0] = Y_set;
				writeData[0]     = 0x30;  /* address of Register*/
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
			/* Offset control Z Register */
			
				txData[0] = Z_set;
				writeData[0]     = 0x31;  /*Address of register*/
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
				/* Back to Active Mode */
				
				txData[0] = 0x01 | 0x04 ; 	// FOR DATA RATE SELECTION OF 640ms.	0x3D
																		// FOR DATA RATE SELECTION OF 10ms.   0x1D
																		// CHECK CONTROL REG 1 
				
				writeData[0]     = 0x2A;  /* address of Control Register 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
}

void SR_Transaction()
{
	ADI_I2C_TRANSACTION SR;
		
			uint8_t SRData[5];
			SRData[0]     = 0x00;  /* address of Read Register */
      SR.bReadNotWrite   = true;
      SR.bRepeatStart    = true;
			SR.nDataSize       = 1;
			SR.nPrologueSize = 1;
			SR.pData           = SR_Data;
			SR.pPrologue = &SRData[0];
      
			reg_val=0;

			while(!reg_val)
			{
				result = adi_i2c_ReadWrite(hDevice, &SR, &hwErrors); 
				reg_val = SR_Data[0]&0x08;
			}
}

uint8_t X_MSB()
{
	ADI_I2C_TRANSACTION X;
		
				uint8_t XData[5];
				XData[0]     = 0x01;  /* address of Read Register */
        X.bReadNotWrite   = true;
        X.bRepeatStart    = true;
				X.nDataSize       = 1;
				X.nPrologueSize = 1;
				X.pData           = X_Data;
				X.pPrologue = &XData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &X, &hwErrors);
	
				return X_Data[0];
	
}
				
uint8_t Y_MSB()
{
	// Reading Y - MSB
			
				ADI_I2C_TRANSACTION Y;
		
				uint8_t YData[5];
				YData[0]     = 0x03;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 1;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];
}

uint8_t Z_MSB()
{
		// Reading Z - MSB
			
				ADI_I2C_TRANSACTION Z;
		
				uint8_t ZData[5];
				ZData[0]     = 0x05;  /* address of Read Register */
        Z.bReadNotWrite   = true;
        Z.bRepeatStart    = true;
				Z.nDataSize       = 1;
				Z.nPrologueSize = 1;
				Z.pData           = Z_Data;
				Z.pPrologue = &ZData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Z, &hwErrors);
				
				return Z_Data[0];
}

uint8_t X_LSB()
{
	// Reading X - LSB
			
				ADI_I2C_TRANSACTION x;
		
				uint8_t xData[5];
				xData[0]     = 0x02;  /* address of Read Register */
        x.bReadNotWrite   = true;
        x.bRepeatStart    = true;
				x.nDataSize       = 1;
				x.nPrologueSize = 1;
				x.pData           = x_Data;
				x.pPrologue = &xData[0];
				
				result = adi_i2c_ReadWrite(hDevice, &x, &hwErrors);
				
				return x_Data[0] ;
	
}

uint8_t Y_LSB()
{
		// Reading Y - LSB
			
				ADI_I2C_TRANSACTION y;
		
				uint8_t yData[5];
				yData[0]     = 0x04;  /* address of Read Register */
        y.bReadNotWrite   = true;
        y.bRepeatStart    = true;
				y.nDataSize       = 1;
				y.nPrologueSize = 1;
				y.pData           = y_Data;
				y.pPrologue = &yData[0];
				
				result = adi_i2c_ReadWrite(hDevice, &y, &hwErrors);
	
				return y_Data[0];
				
}

uint8_t Z_LSB()
{
	
	// Reading Z - LSB
			
				ADI_I2C_TRANSACTION z;
		
				uint8_t zData[5];
				zData[0]     = 0x06;  /* address of Read Register */
        z.bReadNotWrite   = true;
        z.bRepeatStart    = true;
				z.nDataSize       = 1;
				z.nPrologueSize = 1;
				z.pData           = z_Data;
				z.pPrologue = &zData[0];
	
				result = adi_i2c_ReadWrite(hDevice, &z, &hwErrors);
				return z_Data[0];
	
}
/***********************************Interrupt Config**************************************************/
int32_t adi_initComponents(void)
{
	int32_t result = 0;


	if (result == 0) {
		result = adi_initpinmux(); /* auto-generated code (order:0) */
	}

	return result;
}


/*
 * Initialize the Port Control MUX Registers
 */
int32_t adi_initpinmux(void) {
		*((volatile uint32_t *)REG_GPIO0_CFG) |= I2C0_SCL0_PORTP0_MUX | I2C0_SDA0_PORTP0_MUX;
    return 0;
}
void conf_CLK  ( void )
{
	/* Disable key protection for clock oscillator	 */
	pADI_CLKG0_OSC->KEY	 =	 0xCB14U;

	/*
	 * - Internal 32 kHz oscillator is selected
	 * - The HFOSC oscillator ( 26MHz ) is enabled
	 */
	pADI_CLKG0_OSC->CTL	&=	~( 1U << BITP_CLKG_OSC_CTL_LFCLKMUX );
	pADI_CLKG0_OSC->CTL	|=	 ( 1U << BITP_CLKG_OSC_CTL_HFOSCEN  );

	/* Configure dividers
	 *  - ACLK/4 = 26MHz/4 = 6.5MHz
	 *  - HCLK/4 = 26MHz/4 = 6.5MHz
	 *  - PCLK/4 = 26MHz/4 = 6.5MHz
	 */
	pADI_CLKG0_CLK->CTL1	&=	~( ( 0xFF << BITP_CLKG_CLK_CTL1_ACLKDIVCNT ) | ( 0x3F << BITP_CLKG_CLK_CTL1_PCLKDIVCNT ) | ( 0x3F << BITP_CLKG_CLK_CTL1_HCLKDIVCNT ) );
	pADI_CLKG0_CLK->CTL1	|=	 ( ( 0x04 << BITP_CLKG_CLK_CTL1_ACLKDIVCNT ) | ( 0x04 << BITP_CLKG_CLK_CTL1_PCLKDIVCNT ) | ( 0x04 << BITP_CLKG_CLK_CTL1_HCLKDIVCNT ) );

	/* Wait for HFOSC and LFXTAL to stabilize */
	while ( ( pADI_CLKG0_OSC->CTL & ( ( 1U << BITP_CLKG_OSC_CTL_HFOSCOK ) | ( 1U << BITP_CLKG_OSC_CTL_LFOSCOK ) ) ) != ( ( 1U << BITP_CLKG_OSC_CTL_HFOSCOK ) | ( 1U << BITP_CLKG_OSC_CTL_LFOSCOK ) ) )
	{
	}

	/* Block registers	 */
	pADI_CLKG0_OSC->KEY	 =	 0x0000U;
	//int UrtCfg(int iBaud);
	//UrtCfg(230400);
}

/*
 *					TMR0:
 * 						- TMR0_CLK: LFOSC/4 = 32768Hz/4 = 8192Hz
 * 						- Count down
 * 						- Periodic mode
 * 						- Interrupt enabled
 * 						- Overflow: 1s ( 8192 / 8192Hz = 1s )
  */
void conf_Timer0  ( void )
{
	/* Timer0 must be released before is configured	 */
	while ( ( pADI_TMR0->STAT & ( 1U << BITP_TMR_STAT_BUSY ) ) == ( 1U << BITP_TMR_STAT_BUSY ) );

	/* Timer0
	 *  - Synchronization bypass is disabled
	 *  - Event will not be captured
	 *  - TMR0 disabled
	 *  - TMR0 CLK: LFOSC ( 32768 Hz )
	 *  - TMR0 Prescaler: TMR0_CLK/4 ( 32768Hz / 4 = 8192Hz )
	 *  - Timer is set to count down
	 *	- Timer runs in periodic mode
	 */
	pADI_TMR0->CTL	&=	~( ( 1U << BITP_TMR_CTL_SYNCBYP ) | ( 1U << BITP_TMR_CTL_EVTEN ) | ( 0x03 << BITP_TMR_CTL_CLK ) | ( 1U << BITP_TMR_CTL_EN ) | ( 0x03 << BITP_TMR_CTL_PRE ) );
	pADI_TMR0->CTL	|=	 ( ( 0x02 << BITP_TMR_CTL_CLK ) | ( 1U << BITP_TMR_CTL_MODE ) );

	/* Timer0
	 *  - Overflow every ~ 1 second ( 8192 * ( 1/ 8192 ) = 1s )
	 */
	pADI_TMR0->LOAD	 =	 275U;   //  ~30Hz
  
	/* Clear interrupt: Timeout	 */
	pADI_TMR0->CLRINT	|=	 ( 1U << BITP_TMR_CLRINT_TIMEOUT );

	/* Enable interrupt	 */
	NVIC_SetPriority ( TMR0_EVT_IRQn, 0UL );
	NVIC_EnableIRQ   ( TMR0_EVT_IRQn );

	/* Enable Timer0	 */
	pADI_TMR0->CTL	|=	 ( 1U << BITP_TMR_CTL_EN );
}



/**
 *
 *
 *					TMR1:
 * 						- TMR1_CLK: 26MHz divided by 1 PCLK divided by 64 = 406250
 * 						- Count down   
 * 						- Periodic mode
 * 						- Interrupt enabled 
 * 						- Overflow: ~0.5s ( 13542 * ( 1/406250Hz ) ~ 0.03s )
 
 */
void conf_Timer1  ( void )
{
	/* Timer1 must be released before is configured	 */
	while ( ( pADI_TMR1->STAT & ( 1U << BITP_TMR_STAT_BUSY ) ) == ( 1U << BITP_TMR_STAT_BUSY ) );

	pADI_TMR1->CTL	&=	~( ( 1U << BITP_TMR_CTL_SYNCBYP ) | ( 1U << BITP_TMR_CTL_EVTEN ) | ( 0x03 << BITP_TMR_CTL_CLK ) | ( 1U << BITP_TMR_CTL_EN ) | ( 0x03 << BITP_TMR_CTL_PRE ) );
	pADI_TMR1->CTL	|=	 ( ( 1U << BITP_TMR_CTL_MODE ) | ( 0x02 << BITP_TMR_CTL_PRE ) );


	pADI_TMR1->LOAD	 =	13542U;  //  

	/* Clear interrupt: Timeout	 */
	pADI_TMR1->CLRINT	|=	 ( 1U << BITP_TMR_CLRINT_TIMEOUT );

	/* Enable interrupt	 */
	NVIC_SetPriority ( TMR1_EVT_IRQn, 0UL );
	NVIC_EnableIRQ   ( TMR1_EVT_IRQn );

	/* Enable Timer1	 */
	pADI_TMR1->CTL	|=	 ( 1U << BITP_TMR_CTL_EN );
}


/*******************Handler Error************************/
void GP_Tmr1_Int_Handler ( void )
{
	/* Check if TMR1 interrupt pending	 */
	if ( ( pADI_TMR1->STAT & ( 1U << BITP_TMR_STAT_TIMEOUT ) ) == ( 1U << BITP_TMR_STAT_TIMEOUT ) )
	{
		/* Blink LED	 */
		//pADI_GPIO1->TGL	|=	 DS4;
		signal3=1;
		

		/* Clear IRQ	 */
		pADI_TMR1->CLRINT	|=	 ( 1U << BITP_TMR_CLRINT_TIMEOUT );
		

	}

}
/*******************Handler Error************************/

void GP_Tmr0_Int_Handler ( void )
{
	/* Check if TMR0 interrupt pending	 */
	if ( ( pADI_TMR0->STAT & ( 1U << BITP_TMR_STAT_TIMEOUT ) ) == ( 1U << BITP_TMR_STAT_TIMEOUT ) )
	{
		/* Blink LED	 */
		//pADI_GPIO2->TGL	|=	 DS3;
		signal1=1;
		
		/* Clear IRQ	 */
		pADI_TMR0->CLRINT	|=	 ( 1U << BITP_TMR_CLRINT_TIMEOUT );
		
	}
}
/********************************************************************************************************/

void conf_WDT  ( void )
{
	/* Disable WDT	 */
	pADI_WDT0->CTL	&=	~( 1U << BITP_WDT_CTL_EN );

	/*
	 * WDT Configuration:
	 * 	- Prescaler: Source clock/1 ( 32768/1 = 32768Hz )
	 * 	- Timer Mode: Periodic mode
	 * 	- IRQ: WDT generates interrupt when timed out
	 */
	pADI_WDT0->CTL	&=	~( 0x03 << BITP_WDT_CTL_PRE );
	pADI_WDT0->CTL	|=	 ( ( 0x00 << BITP_WDT_CTL_PRE ) | ( 1U << BITP_WDT_CTL_MODE ) | ( 1U << BITP_WDT_CTL_IRQ ) );

	/* Load WDT: Overflow every 1s ( 32768 * ( 1 / 32768Hz ) )	 */
	pADI_WDT0->LOAD	 =	 1092U;  // ~30Hz //32768U;

	/* Clear IRQ	 */
	pADI_WDT0->RESTART	 =	 0xCCCC;

	/* Enable interrupt	 */
	NVIC_SetPriority ( WDT_EXP_IRQn, 0UL );
	NVIC_EnableIRQ   ( WDT_EXP_IRQn );

	/* Enable WDT	 */
	pADI_WDT0->CTL	|=	 ( 1U << BITP_WDT_CTL_EN );
}

void WDog_Tmr_Int_Handler ( void )
{
	/* Check if WDT interrupt pending	 */
	if ( ( pADI_WDT0->STAT & ( 1U << BITP_WDT_STAT_IRQ ) ) == ( 1U << BITP_WDT_STAT_IRQ ) )
	{
		/* New action	 */
		signal2	 =	 1;//1UL;

		/* Clear IRQ	 */
		pADI_WDT0->RESTART	 =	 0xCCCC;
	}
}

void standby_Lis(void)
{
			ADI_I2C_TRANSACTION write;
			uint8_t writeData[5];

			txData[0] = 0x00;
			writeData[0]     = 0x2D;  //BW_Rate
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
	
	
}

void setup_Lis(void)
{
	// CTRL_REG1
	
		ADI_I2C_TRANSACTION write;
			uint8_t writeData[5];

			txData[0] = 0x09; //50Hz
			writeData[0]     = 0x2C;  //BW_Rate
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
	
			txData[0] = 0x08;
			writeData[0]     = 0x2D;  //Register CTRL 1 4G Range
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
			
			txData[0] = 0x0A;
			writeData[0]     = 0x31;  //Register CTRL 4
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
}

uint8_t Y_Lis(uint8_t register_name)
{
	
				ADI_I2C_TRANSACTION Y;
				
				uint8_t YData[5];
				YData[0]     = register_name;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 1;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];	
			
}

uint8_t X_Lis(uint8_t register_name)
{
	
				ADI_I2C_TRANSACTION Y;
		
				uint8_t YData[5];
				YData[0]     = register_name;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 1;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];	
}

uint8_t Z_Lis(uint8_t register_name)
{
	
				ADI_I2C_TRANSACTION Y;
		
				uint8_t YData[5];
				YData[0]     = register_name;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 1;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];	
}
