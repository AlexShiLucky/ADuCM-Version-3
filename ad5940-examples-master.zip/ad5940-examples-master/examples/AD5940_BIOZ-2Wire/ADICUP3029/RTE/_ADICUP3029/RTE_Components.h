
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'AD5940_BIOZ-2Wire' 
 * Target:  'ADICUP3029' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ADuCM3029.h"



#endif /* RTE_COMPONENTS_H */
