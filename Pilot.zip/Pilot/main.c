#include <stdint.h>
#include <common.h>
#include "ADUCM3029.h"
#include <adi_processor.h>
#include <drivers/pwr/adi_pwr.h>
#include "platform_drivers.h"
#include "Driver_I2C.h"                 // ARM::CMSIS Driver:I2C:Custom
#include <drivers/gpio/adi_gpio.h>
#include <drivers/i2c/adi_i2c.h>
#include "platform_drivers.h"
#include "drivers/pwr/adi_pwr.h"
#include "adi_i2c.h"                    // AnalogDevices::Device:Drivers:I2C
#include <math.h>


uint32_t AD5940_GetMCUIntFlag(void);uint32_t AD5940_ClrMCUIntFlag(void);

/* GPIO assignments for DEBUG */

typedef struct {
	ADI_GPIO_PORT Port;
	ADI_GPIO_DATA Pins;
} PinMap;

uint8_t error_message[8]={1};
uint8_t txData[1];							/* Data write to MMA8451 */
uint8_t Chip_Data[1];						/* Device ID = 0x1A */ 
uint8_t Data[32] = {0x001};								/* Control Reg 2 Data --> Wait till SET */

/* VARIABLES */

uint8_t X_Lis(uint8_t register_name);
uint8_t Y_Lis(uint8_t register_name);
uint8_t Z_Lis(uint8_t register_name);
void setup_Lis();
void status_Lis();
float count = 0;

uint16_t x_calib[100]={0};
uint16_t y_calib[100]={0};
uint16_t z_calib[100]={0};

uint8_t X_Data[2]; 							/* MSB DATA */
uint8_t Y_Data[2];							/* MSB DATA */	
uint8_t Z_Data[2];							/* MSB DATA */
uint8_t x_Data[2];							/* LSB DATA */
uint8_t y_Data[2];							/* LSB DATA */
uint8_t z_Data[2];							/* LSB DATA */
uint8_t SR_Data[1];							/* Status Register --> Wait till SET */
int X_out;
int Y_out;
int Z_out;
float X_set;
float Y_set;
float Z_set;
float X_g;
float Y_g;
float Z_g;
float xAccl;
float yAccl;
float zAccl;

uint8_t X_Data1[2]; 							/* MSB DATA */
uint8_t Y_Data1[2];							/* MSB DATA */	
uint8_t Z_Data1[2];							/* MSB DATA */
uint8_t x_Data1[2];							/* LSB DATA */
uint8_t y_Data1[2];							/* LSB DATA */
uint8_t z_Data1[2];							/* LSB DATA */
uint8_t SR_Data1[1];							/* Status Register --> Wait till SET */
float X_out1;
float Y_out1;
float Z_out1;
float X_set1;
float Y_set1;
float Z_set1;
float X_g1;
float Y_g1;
float Z_g1;

float buffer_x[3] = {0} ;
float buffer_y[3] = {0} ;
float buffer_z[3] = {0} ;
float buffer_1_x[3] = {0} ;
float buffer_1_y[3] = {0} ;
float buffer_1_z[3] = {0} ;
float mean_x = 0;
float mean_y = 0;
float mean_z = 0;
float mean_1_x = 0;
float mean_1_y = 0;
float mean_1_z = 0;


uint8_t fifo[32] ;
				

#define SENSITIVITY_2G 16380 // LIS15987 MMA4096

/* Variable to Clear Register Values*/
unsigned char reg_val;

void Chip_Id(void);
void wCTRL_2(void);
void set_up(void);
void SR_Transaction(void);
void set_calibration(float X_set,float Y_set,float Z_set);
uint8_t X_MSB(void);
uint8_t Y_MSB(void);
uint8_t Z_MSB(void);
uint8_t X_LSB(void);
uint8_t Y_LSB(void);
uint8_t Z_LSB(void);

int counter;

ADI_I2C_RESULT result = ADI_I2C_SUCCESS;

uint32_t hwErrors;

/* setup I2C Pins */

#define I2C0_SCL0_PORTP0_MUX ((uint16_t) ((uint16_t) 1<<8))
#define I2C0_SDA0_PORTP0_MUX ((uint16_t) ((uint16_t) 1<<10))

#define PB2_PORT_NUM        ADI_GPIO_PORT0
#define PB2_PIN_NUM         ADI_GPIO_PIN_15

int32_t adi_initpinmux(void) 
	{
   
    *((volatile uint32_t *)REG_GPIO0_CFG) |= I2C0_SCL0_PORTP0_MUX | I2C0_SDA0_PORTP0_MUX;

    return 1;
	}


PinMap MSB = {ADI_GPIO_PORT1, ADI_GPIO_PIN_15};  /*   Red LED on GPIO31 (DS4) */
PinMap LSB = {ADI_GPIO_PORT2, ADI_GPIO_PIN_0};   /* Green LED on GPIO32 (DS3) */


extern uint32_t SystemCoreClock;

uint8_t devMem[ADI_I2C_MEMORY_SIZE]; /* assign memory */

ADI_I2C_HANDLE hDevice;    /* device */

volatile static uint32_t ucInterrupted = 0;
static uint32_t IntCount;


void Event_A_Int_Handler(void)
{
   pADI_XINT0->CLR = BITM_XINT_CLR_IRQ0;
   ucInterrupted = 1;  
}

int main(void)
{
uint8_t         gpioMemory[ADI_GPIO_MEMORY_SIZE] = {0};
uint8_t devMem[ADI_I2C_MEMORY_SIZE];

	ADI_PWR_RESULT  ePwrResult;
	ADI_GPIO_RESULT eGpioResult;
	ADI_GPIO_RESULT eResult;

	/* common init */
	adi_pwr_Init();
	adi_initpinmux();
	common_Init();

		ePwrResult = adi_pwr_Init();
		DEBUG_RESULT("adi_pwr_Init failed.", ePwrResult, ADI_PWR_SUCCESS);
		ePwrResult = adi_pwr_SetClockDivider(ADI_CLOCK_HCLK, 1u);
		DEBUG_RESULT("adi_pwr_SetClockDivider (HCLK) failed.", ePwrResult, ADI_PWR_SUCCESS);
		ePwrResult = adi_pwr_SetClockDivider(ADI_CLOCK_PCLK, 1u);
		DEBUG_RESULT("adi_pwr_SetClockDivider (PCLK) failed.", ePwrResult, ADI_PWR_SUCCESS);

    /* Initialize GPIO driver */
    eGpioResult= adi_gpio_Init(gpioMemory, ADI_GPIO_MEMORY_SIZE);
    DEBUG_RESULT("adi_GPIO_Init failed.", eGpioResult, ADI_GPIO_SUCCESS);
    eGpioResult = adi_gpio_OutputEnable(MSB.Port, MSB.Pins, true);
    DEBUG_RESULT("adi_GPIO_SetOutputEnable failed on MSB.", eGpioResult, ADI_GPIO_SUCCESS);
    eGpioResult = adi_gpio_OutputEnable(LSB.Port, LSB.Pins, true);
    DEBUG_RESULT("adi_GPIO_SetOutputEnable failed on LSB.", eGpioResult, ADI_GPIO_SUCCESS);
		
		  pADI_XINT0->CFG0 = (0x1<<0)|(1<<3);//External IRQ0 enabled. Falling edge
			pADI_XINT0->CLR = BITM_XINT_CLR_IRQ0;
			NVIC_EnableIRQ(XINT_EVT0_IRQn);		  //Enable External Interrupt 0 source.
       
		if (adi_i2c_Open(0, devMem, ADI_I2C_MEMORY_SIZE, &hDevice))
    {
        DEBUG_MESSAGE("Failed adi_i2c_Open.");
    }

    if (adi_i2c_Reset(hDevice))
    {
       DEBUG_MESSAGE("adi_i2c_Reset.");
		}
   
		/* check set speed API */
    
		if (adi_i2c_SetBitRate(hDevice, 400000)) // top-end
			{
       DEBUG_MESSAGE("adi_i2c_SetBitRate 400000.");
			}
			
		if(ADI_GPIO_SUCCESS != (eResult = adi_gpio_InputEnable(PB2_PORT_NUM, PB2_PIN_NUM, true)))
        {
            DEBUG_MESSAGE("adi_gpio_InputEnable failed\n");
            exit(0);
        }
			if(ADI_GPIO_SUCCESS != (eResult = adi_gpio_SetGroupInterruptPins(PB2_PORT_NUM, ADI_GPIO_INTA_IRQ, PB2_PIN_NUM)))
            {
                DEBUG_MESSAGE("adi_gpio_SetGroupInterruptPins failed\n");
                exit(0);
            }      
			
			NVIC_EnableIRQ(SYS_GPIO_INTA_IRQn);
			
			// START DATA RECORDING 
			
			
			/* init some variable*/ 
 
			//counter =  0;
			//float sum_x=0;float sum_y=0;float sum_z=0;
			//float sum_1_x=0;float sum_1_y=0;float sum_1_z=0;
		
	while(1){	
		if (adi_i2c_SetSlaveAddress(hDevice,0x53)) // bottom-end
			{
		//	DEBUG_MESSAGE("couldn't set slave device address");
			}
			
			/* REQUIRED */
			
	//		Chip_Id();  /* Read CHIP ID */
	//		wCTRL_2();
	//		set_up();   /// REMOVE FIFO PART
	//		while(1)
//{
	setup_Lis();
			
	//		while(1)
	//		{
	//		status_Lis();
//			int x = 0;
//			while(x<100)
//			{				
//			Z_Data[0] = Z_Lis(0x37);
//			z_Data[0] = Z_Lis(0x36);
//			Y_Data[0] = Y_Lis(0x35);
//			y_Data[0] = Y_Lis(0x34);
//			X_Data[0] = X_Lis(0x33);
//			x_Data[0] = X_Lis(0x32);
//			
//			x_calib[x]=( X_Data[0]<<8) | (x_Data[0]);
//			y_calib[x]=( Y_Data[0]<<8) | (y_Data[0]);
//			z_calib[x]=( Z_Data[0]<<8) | (z_Data[0]);
//			
//				x=x+1;
//			count = count + 1;
//				
//			}
//			int x_cal=0;
//			int y_cal=0;
//			int z_cal=0;
//			for(int i =0 ; i<100;i++)
//			{
//				x_cal = x_cal + x_calib[i];
//				y_cal = y_cal + y_calib[i];
//				z_cal = z_cal + z_calib[i];
//			}
//			
//			x_cal = x_cal/100;
//			y_cal = y_cal/100;
//			z_cal = z_cal/100;
//			
//			ADI_I2C_TRANSACTION write;
//			txData[0] = x_cal;
//			uint8_t writeData[5];     
//			writeData[0]     = 0x1E;  //Register CTRL 1 4G Range
//			write.bReadNotWrite = false;
//			write.bRepeatStart = false;
//			write.nDataSize = 1;
//			write.nPrologueSize = 1;
//			write.pData = txData;
//			write.pPrologue = &writeData[0];

//			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
//			
//			
//			txData[0] = y_cal;
//			writeData[0]     = 0x1F;  //Register CTRL 1 4G Range
//			write.bReadNotWrite = false;
//			write.bRepeatStart = false;
//			write.nDataSize = 1;
//			write.nPrologueSize = 1;
//			write.pData = txData;
//			write.pPrologue = &writeData[0];

//			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
//			
//			
//			txData[0] = z_cal;    
//			writeData[0]     = 0x20;  //Register CTRL 1 4G Range
//			write.bReadNotWrite = false;
//			write.bRepeatStart = false;
//			write.nDataSize = 1;
//			write.nPrologueSize = 1;
//			write.pData = txData;
//			write.pPrologue = &writeData[0];

//			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
    //while(1)
		//{
			x_Data[0] = X_Lis(0x32);
			X_Data[0] = X_Lis(0x33);
			y_Data[0] = X_Lis(0x34);			
			Y_Data[0] = X_Lis(0x35);
			z_Data[0] = Z_Lis(0x36);			
			Z_Data[0] = Z_Lis(0x37);


//			if(AD5940_GetMCUIntFlag())
//			{
//      AD5940_ClrMCUIntFlag(); /* Clear this flag */
//			}
//			
//			ADI_I2C_TRANSACTION read;		
//			uint8_t readData[32];
//			readData[0]     = 0x0C;  /* address of Read Register */
//      read.bReadNotWrite   = true;
//      read.bRepeatStart    = false;
//			read.nDataSize       = 1;
//			read.nPrologueSize = 1;
//			read.pData           = Data;
//			read.pPrologue = &readData[0];
//		
//			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
//				
//			SR_Transaction();
//			
//			readData[0]     = 0x01;  /* address of Read Register */
//      read.bReadNotWrite   = true;
//      read.bRepeatStart    = true;
//			read.nDataSize       = 2;
//			read.nPrologueSize = 1;
//			read.pData           = Data;
//			read.pPrologue = &readData[0];
//			
//			do
//			{
//			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
//			fifo[0]=Data[0];
//			}while(Data[0]!=NULL);
//			
		
		
//			wCTRL_2();	/* Control Reg 2 writing */
//			
//			ADI_I2C_TRANSACTION read;		
//			uint8_t readData[5];
//			readData[0]     = 0x2B;  /* address of Read Register */
//      read.bReadNotWrite   = true;
//      read.bRepeatStart    = false;
//			read.nDataSize       = 1;
//			read.nPrologueSize = 1;
//			read.pData           = Data;
//			read.pPrologue = &readData[0];
//			
//			do{
//			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
//			reg_val = Data[0]&0x40;
//			} 
//			while(reg_val);
//			
//			set_up();
//			
//			SR_Transaction();
//			
//				eGpioResult = adi_gpio_SetLow(MSB.Port,  MSB.Pins); 
//				eGpioResult = adi_gpio_SetLow(LSB.Port,  LSB.Pins);
			
			/* REQUIRED */
			
//	
//				ADI_I2C_TRANSACTION X;
//		
//				uint8_t XData[5];
//				XData[0]     = 0x01;  /* address of Read Register */
//        X.bReadNotWrite   = true;
//        X.bRepeatStart    = true;
//				X.nDataSize       = 1;
//				X.nPrologueSize = 1;
//				X.pData           = X_Data;
//				X.pPrologue = &XData[0];
//			
//	
//				result = adi_i2c_ReadWrite(hDevice, &X, &hwErrors);
//				
//				Y_Data[0]=X_Data[0];
			//}
				
			
			
/********************************************VERSION *****************************************************/			
			
//			X_Data[0] = X_MSB();
//			Y_Data[0] = Y_MSB();
//			Z_Data[0] = Z_MSB();
//			x_Data[0] = X_LSB();
//			y_Data[0] = X_LSB();
//			z_Data[0] = Z_LSB();			
//			
//			X_out = ((short) (X_Data[0]<<8 | x_Data[0])) >> 2;           // Compute 14-bit X-axis output value
//			Y_out = ((short) (Y_Data[0]<<8 | y_Data[0])) >> 2;           // Compute 14-bit Y-axis output value
//			Z_out = ((short) (Z_Data[0]<<8 | z_Data[0])) >> 2;           // Compute 14-bit Z-axis output value	
//					
//			X_set = X_out / 8 * (-1);        											// Compute X-axis offset 
//			Y_set = Y_out / 8 * (-1);        											// Compute Y-axis offset 
//			Z_set = (Z_out - SENSITIVITY_2G) / 8 * (-1);          // Compute Z-axis offset 
//				
//			set_calibration(X_set,Y_set,Z_set);
//			
//			/*
//			eGpioResult = adi_gpio_SetLow(MSB.Port,  MSB.Pins); 
//			eGpioResult = adi_gpio_SetLow(LSB.Port,  LSB.Pins);
//			                                                              USE FOR DEBUG           */
//			
//			//SR_Transaction();
//			
//			/* Data from Slave Device 1 */
//				
//			X_Data[0] = X_MSB();Y_Data[0] = Y_MSB();Z_Data[0] = Z_MSB();
//			x_Data[0] = X_LSB();y_Data[0] = Y_LSB();z_Data[0] = Z_LSB();
//				
			 xAccl = ((X_Data[0] & 0x03) * 256 + (x_Data[0] & 0xFF));
			if(xAccl > 511)
		{
			xAccl -= 1024;
		}

		yAccl = ((Y_Data[0] & 0x03) * 256 + (y_Data[0] & 0xFF));
		//if(yAccl > 511)
		//{
		//	yAccl -= 1024;
		//}

		 zAccl = ((Z_Data[0] & 0x03) * 256 + (z_Data[0] & 0xFF));
		if(zAccl > 511)
		{
			zAccl -= 1024;
		}
	
		
			X_g = (xAccl/255)*9.89 ; //( (((float) X_out)) * 0.0039 /256)*9.8 ;              // Value in g's
			Y_g = (yAccl/255)*9.89 ; //( (((float) Y_out)) * 0.0039 /256)*9.8 ;              // Value in g's
			Z_g = (zAccl/255)*9.89 ; //( (((float) Z_out)) * 0.0039 /256)*9.8 ;							 // Value in g's
//				
//			/*	
//			eGpioResult = adi_gpio_SetHigh(MSB.Port,  MSB.Pins); 
//			eGpioResult = adi_gpio_SetHigh(LSB.Port,  LSB.Pins); Used for Debug*/
//			
//			if (adi_i2c_SetSlaveAddress(hDevice,0X1D)) // bottom-end
//			{
//			DEBUG_MESSAGE("couldn't set slave device address");
//			}
//			
//			Chip_Id();  /* Read CHIP ID for Verification of Device Recogition*/
//			wCTRL_2();	/* Control Reg 2 writing */
//			
//			readData[0]     = 0x2B;  /* address of Read Register */
//      read.bReadNotWrite   = true;
//      read.bRepeatStart    = false;
//			read.nDataSize       = 1;
//			read.nPrologueSize = 1;
//			read.pData           = Data;
//			read.pPrologue = &readData[0];
//			
//			do{
//			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); 
//			reg_val = Data[0]&0x40;
//			} 
//			while(reg_val);
//			
//			set_up();
//			SR_Transaction();
//			
//			X_Data1[0] = X_MSB();
//			Y_Data1[0] = Y_MSB();
//			Z_Data1[0] = Z_MSB();
//			x_Data1[0] = X_LSB();
//			y_Data1[0] = X_LSB();
//			z_Data1[0] = Z_LSB();			
//			
//			X_out1 = ((short) (X_Data1[0]<<8 | x_Data1[0])) >> 2;           // Compute 14-bit X-axis output value
//			Y_out1 = ((short) (Y_Data1[0]<<8 | y_Data1[0])) >> 2;           // Compute 14-bit Y-axis output value
//			Z_out1 = ((short) (Z_Data1[0]<<8 | z_Data1[0])) >> 2;           // Compute 14-bit Z-axis output value	
//				
//			X_set1 = X_out1 / 8 * (-1);        											// Compute X-axis offset 
//			Y_set1 = Y_out1 / 8 * (-1);        											// Compute Y-axis offset 
//			Z_set1 = (Z_out1 - SENSITIVITY_2G) / 8 * (-1);          // Compute Z-axis offset 
//				
//			set_calibration(X_set1,Y_set1,Z_set1);
//			
//			/* Start Reading Data from Slave Device 2*/
//				
//			X_Data1[0] = X_MSB();
//			Y_Data1[0] = Y_MSB();
//			Z_Data1[0] = Z_MSB();
//			x_Data1[0] = X_LSB();
//			y_Data1[0] = Y_LSB();
//			z_Data1[0] = Z_LSB();
//				
//			X_out1 = ((short) (X_Data1[0]<<8 | x_Data1[0])) >> 2;           // Compute 14-bit X-axis output value
//			Y_out1 = ((short) (Y_Data1[0]<<8 | y_Data1[0])) >> 2;           // Compute 14-bit Y-axis output value
//			Z_out1 = ((short) (Z_Data1[0]<<8 | z_Data1[0])) >> 2;           // Compute 14-bit Z-axis output value	
//				
//			X_g1 = (((float) X_out1) / SENSITIVITY_2G)*9.8;              // Value in g's
//			Y_g1 = (((float) Y_out1) / SENSITIVITY_2G)*9.8;              // Value in g's
//			Z_g1 = (((float) Z_out1) / SENSITIVITY_2G)*9.8;							 // Value in g's
//				
//			
			eGpioResult = adi_gpio_SetHigh(MSB.Port,  MSB.Pins); 
			eGpioResult = adi_gpio_SetHigh(LSB.Port,  LSB.Pins);
//				
//			
//			
//			if(counter < 3)
//			{
//				buffer_x[counter]	=	X_g;
//				buffer_y[counter] = Y_g;
//				buffer_z[counter]	=	Z_g;
//				buffer_1_x[counter]	=	X_g1;
//				buffer_1_y[counter] = Y_g1;
//				buffer_1_z[counter]	=	Z_g1;

//				counter = counter + 1;
//			}
//			else
//			{	
//				   for(int k = 0; k < 3; k++)
//				{
//							sum_x +=buffer_x[k];sum_y +=buffer_y[k];sum_z +=buffer_z[k];
//							sum_1_x +=buffer_1_x[k];sum_1_y +=buffer_1_y[k];sum_1_z +=buffer_1_z[k];
//				}
//				mean_x = sum_x /3;mean_y = sum_y /3;mean_z = sum_z /3;
//				mean_1_x = sum_1_x /3;mean_1_y = sum_1_y /3;mean_1_z= sum_1_z /3;
//				
//				sum_x =0;sum_y =0;sum_z =0;sum_1_x =0;sum_1_y =0;sum_1_z =0;
//				counter = 0;
//				
//				buffer_x[counter]	=	X_g;
//				buffer_y[counter] = Y_g;
//				buffer_z[counter]	=	Z_g;
//				buffer_1_x[counter]	=	X_g1;
//				buffer_1_y[counter] = Y_g1;
//				buffer_1_z[counter]	=	Z_g1;
//				
//				counter = counter + 1;
//			}
//				float threshold = 1;
//			
//			 if ((mean_x != X_g && fabs(mean_x-X_g)>threshold) || (mean_y != Y_g && fabs(mean_y-Y_g)>threshold) || (mean_z != Z_g && fabs(mean_z-Z_g)>threshold)) 
//					{
//								printf("Movement Detected");
//					}  
//				else
//				{
//								printf("Stationary");
//				}
//       
//			
//				//printf("\n X_g = %f Y_g = %f Z_g = %f X_g1 = %f Y_g1 = %f Z_g1 = %f ",X_g,Y_g,Z_g,X_g1,Y_g1,Z_g1);
//				//printf("\n X_g = %f Y_g = %f Z_g = %f X_g1 = %f Y_g1 = %f Z_g1 = %f ",mean_x,mean_y,mean_z,mean_1_x,mean_1_y,mean_1_z);
//				
			//__nop();
			//__nop();
			common_Pass();		
				
				}

	return 0;
}

/*******************************MMA8451 I2C SETUP FUNCTIONS************************************************/
/**********************************************************************************************************/
/**********************************************************************************************************/
/**********************************************************************************************************/
/**********************************************************************************************************/
void Chip_Id()
{
				ADI_I2C_TRANSACTION xfr;
		
			uint8_t prologueData[5];
			prologueData[0]     = 0x00;  /* address of 1st Chip Id Register */
      xfr.bReadNotWrite   = true;
      xfr.bRepeatStart    = true;
			xfr.nDataSize       = 1;
			xfr.nPrologueSize = 1;
			xfr.pData           = Chip_Data;
			xfr.pPrologue = &prologueData[0];;
      
      result = adi_i2c_ReadWrite(hDevice, &xfr, &hwErrors);
			if(result){
				exit(1);
			}
}

void setup_Lis()
{
	// CTRL_REG1
	
		ADI_I2C_TRANSACTION write;
			uint8_t writeData[5];

			txData[0] = 0x0A;
			writeData[0]     = 0x2C;  //BW_Rate
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
	
			txData[0] = 0x08;
			writeData[0]     = 0x2D;  //Register CTRL 1 4G Range
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
			
			txData[0] = 0x0A;
			writeData[0]     = 0x31;  //Register CTRL 4
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
}

void status_Lis()
	
{
		ADI_I2C_TRANSACTION SR;
		
			uint8_t SRData[5];
			SRData[0]     = 0x27;  /* address of Read Register */
      SR.bReadNotWrite   = true;
      SR.bRepeatStart    = true;
			SR.nDataSize       = 1;
			SR.nPrologueSize = 1;
			SR.pData           = SR_Data;
			SR.pPrologue = &SRData[0];
      
			reg_val=0;

			while(!reg_val)
			{
				result = adi_i2c_ReadWrite(hDevice, &SR, &hwErrors); 
				reg_val = SR_Data[0]&0x08;
			}
}

uint8_t Y_Lis(uint8_t register_name)
{
	
				ADI_I2C_TRANSACTION Y;
				
				uint8_t YData[5];
				YData[0]     = register_name;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 2;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];	
			
}

uint8_t X_Lis(uint8_t register_name)
{
	
				ADI_I2C_TRANSACTION Y;
		
				uint8_t YData[5];
				YData[0]     = register_name;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 2;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];	
}

uint8_t Z_Lis(uint8_t register_name)
{
	
				ADI_I2C_TRANSACTION Y;
		
				uint8_t YData[5];
				YData[0]     = register_name;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 2;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];	
}


void wCTRL_2()
{
//WRITE 0x40
	
	ADI_I2C_TRANSACTION write;
			txData[0] = 0x40;
			uint8_t writeData[5];
			writeData[0]     = 0x2B;  
			write.bReadNotWrite = false;
			write.bRepeatStart = false;
			write.nDataSize = 1;
			write.nPrologueSize = 1;
			write.pData = txData;
			write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
				
			if (result){exit(1);}
			
}



void set_up()
{
//						//RANGE
				ADI_I2C_TRANSACTION write;
				uint8_t writeData[5];
				txData[0] = 0x00 ;
				
//				writeData[0]     = 0x0E;  /* address of XYZ DATA CONFIG */
//				write.bReadNotWrite = false;
//				write.bRepeatStart = false;
//				write.nDataSize = 1;
//				write.nPrologueSize = 1;
//				write.pData = txData;
//				write.pPrologue = &writeData[0];

//				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
//				
//					
//					// HIGH RESOLUTION 
//					
//				txData[0] = 0x02;
//				writeData[0]     = 0x2B;  /* address of 1st Control Reg 2 */
//				write.bReadNotWrite = false;
//				write.bRepeatStart = false;
//				write.nDataSize = 1;
//				write.nPrologueSize = 1;
//				write.pData = txData;
//				write.pPrologue = &writeData[0];

//				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
//			
//			//DRY INT CTRL REG 4
//			
//				txData[0] = 0x01;
//				writeData[0]     = 0x2D;  
//				write.bReadNotWrite = false;
//				write.bRepeatStart = false;
//				write.nDataSize = 1;
//				write.nPrologueSize = 1;
//				write.pData = txData;
//				write.pPrologue = &writeData[0];

//			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
//			
//			//DRY INT CTRL REG 5
//			
//				txData[0] = 0x01;
//				writeData[0]     = 0x2E;  /* address of 1st Control Reg 5 */
//				write.bReadNotWrite = false;
//				write.bRepeatStart = false;
//				write.nDataSize = 1;
//				write.nPrologueSize = 1;
//				write.pData = txData;
//				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
		/**FIFO**********************************************************************/	
						//LOW NOISE
			
				txData[0] = 0x18  ;  //0x01 | 0x04;           //0x1C ;				// 0x01 | 0x04;
				writeData[0]     = 0x2A;  /* address of 1st Control Reg 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);	
				
				txData[0] = 0x80 ;				// 0x01 | 0x04;
				writeData[0]     = 0x09;  /* address of FIFO */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);

			txData[0] = 0x40 ;				// 0x01 | 0x04;
				writeData[0]     = 0x2D;  /* Enable Interrupt for FIFO */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
						txData[0] = 0x40 ;				// 0x01 | 0x04;
				writeData[0]     = 0x2E;  /* Set Route INT1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
			
						txData[0] = 0x11 ;				// 0x01 | 0x04;
				writeData[0]     = 0x0E;  /* address of FIFO */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
			ADI_I2C_TRANSACTION read;		
			uint8_t readData[5];
			readData[0]     = 0x2B;  /* address of Read Register */
      read.bReadNotWrite   = true;
      read.bRepeatStart    = false;
			read.nDataSize       = 1;
			read.nPrologueSize = 1;
			read.pData           = Data;
			read.pPrologue = &readData[0];
			
			
			result = adi_i2c_ReadWrite(hDevice, &read, &hwErrors); //set_up();
			reg_val = Data[0];
			reg_val |= 0x01;
			
			
							txData[0] =  reg_val;//0x1D ; 	// FOR DATA RATE SELECTION OF 640ms.	0x3D
														// FOR DATA RATE SELECTION OF 10ms.   0x1D
														// CHECK CONTROL REG 1 
				
				writeData[0]     = 0x2A;  /* address of Control Register 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
				
}

void set_calibration(float X_set,float Y_set,float Z_set)
{
					/* Put MMA into Standby Mode */
				ADI_I2C_TRANSACTION write;
				uint8_t writeData[5];
				txData[0] = 0x00 ;
				
				writeData[0]     = 0x2A;  /* address of Control Register 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
	
				/* Offset control X Register */
				
				txData[0] = X_set ;
				
				writeData[0]     = 0x2F;  /* address of Register */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
				
				/* Offset control Y Register */
					
					
				txData[0] = Y_set;
				writeData[0]     = 0x30;  /* address of Register*/
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
			/* Offset control Z Register */
			
				txData[0] = Z_set;
				writeData[0]     = 0x31;  /*Address of register*/
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

			result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
			
				/* Back to Active Mode */
				
				txData[0] = 0x1D ; 	// FOR DATA RATE SELECTION OF 640ms.	0x3D
														// FOR DATA RATE SELECTION OF 10ms.   0x1D
														// CHECK CONTROL REG 1 
				
				writeData[0]     = 0x2A;  /* address of Control Register 1 */
				write.bReadNotWrite = false;
				write.bRepeatStart = false;
				write.nDataSize = 1;
				write.nPrologueSize = 1;
				write.pData = txData;
				write.pPrologue = &writeData[0];

				result = adi_i2c_ReadWrite(hDevice, &write, &hwErrors);
}

void SR_Transaction()
{
	ADI_I2C_TRANSACTION SR;
		
			uint8_t SRData[5];
			SRData[0]     = 0x00;  /* address of Read Register */
      SR.bReadNotWrite   = true;
      SR.bRepeatStart    = true;
			SR.nDataSize       = 1;
			SR.nPrologueSize = 1;
			SR.pData           = SR_Data;
			SR.pPrologue = &SRData[0];
      
			reg_val=0;

			while(!reg_val)
			{
				result = adi_i2c_ReadWrite(hDevice, &SR, &hwErrors); 
				reg_val = SR_Data[0]&0x08;
			}
}

uint8_t X_MSB()
{
	ADI_I2C_TRANSACTION X;
		
				uint8_t XData[5];
				XData[0]     = 0x01;  /* address of Read Register */
        X.bReadNotWrite   = true;
        X.bRepeatStart    = true;
				X.nDataSize       = 1;
				X.nPrologueSize = 1;
				X.pData           = X_Data;
				X.pPrologue = &XData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &X, &hwErrors);
	
				return X_Data[0];
	
}
				
uint8_t Y_MSB()
{
	// Reading Y - MSB
			
				ADI_I2C_TRANSACTION Y;
		
				uint8_t YData[5];
				YData[0]     = 0x03;  /* address of Read Register */
        Y.bReadNotWrite   = true;
        Y.bRepeatStart    = true;
				Y.nDataSize       = 1;
				Y.nPrologueSize = 1;
				Y.pData           = Y_Data;
				Y.pPrologue = &YData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Y, &hwErrors);
				return Y_Data[0];
}

uint8_t Z_MSB()
{
		// Reading Z - MSB
			
				ADI_I2C_TRANSACTION Z;
		
				uint8_t ZData[5];
				ZData[0]     = 0x05;  /* address of Read Register */
        Z.bReadNotWrite   = true;
        Z.bRepeatStart    = true;
				Z.nDataSize       = 1;
				Z.nPrologueSize = 1;
				Z.pData           = Z_Data;
				Z.pPrologue = &ZData[0];
			
	
				result = adi_i2c_ReadWrite(hDevice, &Z, &hwErrors);
				
				return Z_Data[0];
}

uint8_t X_LSB()
{
	// Reading X - LSB
			
				ADI_I2C_TRANSACTION x;
		
				uint8_t xData[5];
				xData[0]     = 0x02;  /* address of Read Register */
        x.bReadNotWrite   = true;
        x.bRepeatStart    = true;
				x.nDataSize       = 1;
				x.nPrologueSize = 1;
				x.pData           = x_Data;
				x.pPrologue = &xData[0];
				
				result = adi_i2c_ReadWrite(hDevice, &x, &hwErrors);
				
				return x_Data[0] ;
	
}

uint8_t Y_LSB()
{
		// Reading Y - LSB
			
				ADI_I2C_TRANSACTION y;
		
				uint8_t yData[5];
				yData[0]     = 0x04;  /* address of Read Register */
        y.bReadNotWrite   = true;
        y.bRepeatStart    = true;
				y.nDataSize       = 1;
				y.nPrologueSize = 1;
				y.pData           = y_Data;
				y.pPrologue = &yData[0];
				
				result = adi_i2c_ReadWrite(hDevice, &y, &hwErrors);
	
				return y_Data[0];
				
}

uint8_t Z_LSB()
{
	
	// Reading Z - LSB
			
				ADI_I2C_TRANSACTION z;
		
				uint8_t zData[5];
				zData[0]     = 0x06;  /* address of Read Register */
        z.bReadNotWrite   = true;
        z.bRepeatStart    = true;
				z.nDataSize       = 1;
				z.nPrologueSize = 1;
				z.pData           = z_Data;
				z.pPrologue = &zData[0];
	
				result = adi_i2c_ReadWrite(hDevice, &z, &hwErrors);
				return z_Data[0];
	
}
uint32_t AD5940_GetMCUIntFlag(void)
{
   return ucInterrupted;
}

uint32_t AD5940_ClrMCUIntFlag(void)
{
   ucInterrupted = 0;
   return 1;
}
