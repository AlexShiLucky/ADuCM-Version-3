/*
 **
 ** Source file generated on March 23, 2017 at 17:54:22.	
 **
 ** Copyright (C) 2017 Analog Devices Inc., All Rights Reserved.
 **
 ** This file is generated automatically based upon the options selected in 
 ** the Pin Multiplexing configuration editor. Changes to the Pin Multiplexing
 ** configuration should be made by changing the appropriate options rather
 ** than editing this file.
 **
 ** Selected Peripherals
 ** --------------------
 ** RTC (RTC_SS1)
 **
 ** GPIO (unavailable)
 ** ------------------
 ** P2_11
 */

#include <sys/platform.h>
#include <stdint.h>

#define RTC_RTC_SS1_PORTP2_MUX  ((uint32_t) ((uint32_t) 3<<22))

int32_t adi_initpinmux(void);

/*
 * Initialize the Port Control MUX Registers
 */
int32_t adi_initpinmux(void) {
    /* PORTx_MUX registers */
    *((volatile uint32_t *)REG_GPIO2_CFG) = RTC_RTC_SS1_PORTP2_MUX;

    return 0;
}

