/*
** adi_initialize.h header file generated on April 17, 2017 at 18:51:29.
**
** Copyright (C) 2000-2017 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically. You should not modify this source file,
** as your changes will be lost if this source file is re-generated.
*/

#ifndef __ADI_COMPONENT_INIT_H__
#define __ADI_COMPONENT_INIT_H__
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Declare "adi_initComponents()" */
int32_t adi_initComponents(void);

#ifdef __cplusplus
}
#endif

#endif /* __ADI_COMPONENT_INIT_H__ */

